
delete from access_event_property;
delete from access_event;
